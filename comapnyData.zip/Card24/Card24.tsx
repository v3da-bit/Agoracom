
import Image from 'next/image'
import React, { FC } from 'react'
import PostCard3 from '../Card23/PostCard3'
import { Card3SmallProps } from '../Card3Small/Card3Small'
import DefaultAvatar from '../../images/default-image.jpg';
import moment from 'moment';

const Card24: FC<Card3SmallProps> = ({ post, avatar }) => {
    const style = 'mt-3 font-semibold text-md max-md:text-sm text-gray-600 dark:text-gray-200 text-left line-clamp-6'
    const { title, subTitle, content, href, featuredImage, avatar_url, username, company, company_name, created_at } = post;
    const getUrl = (url: any) => {
        if (url.toString().includes("s3.amazonaws.com")) {
            return url;
        } else {
            return DefaultAvatar;
        }
    }

    return (
        <div className="border overflow-hidden  border-gray-400 rounded-lg dark:bg-neutral-900 dark:border-gray-800  bg-white h-full ">
            <div className='w-full h-auto flex justify-center lg:block '>
                <Image
                    className=' w-full h-52 object-cover'
                    src={getUrl(avatar_url)}
                    alt="GFG logo served with static path of public directory"
                    height="100"
                    width="100"
                /> </div>
            <div className="w-full h-fit p-6">
                <div className="w-full">
                    <h1 className='text-lg max-md:text-md mt-3'>
                        <b>{post.title}</b>
                    </h1>
                </div>


                <h1 className={style} dangerouslySetInnerHTML={{__html: post.content}}></h1>
                <div className="w-full flex  mt-8">
                <span className="block text-blue-500 hover:text-black dark:text-neutral-300 dark:hover:text-white font-medium">
                            {username || post.author?.displayName}
                        </span>
                        <span className="text-neutral-500 dark:text-neutral-400 mx-[6px] font-medium">
                            ·
                        </span>
                        <span className="text-neutral-500 dark:text-neutral-400 font-normal">
                        {created_at ? moment(created_at).fromNow() : post.date}
                        </span>
                </div>
                    <h1 className="text-md font-semibold max-md:text-sm  text-dark">{company_name}</h1>
            </div>


        </div>
    )
}

export default Card24