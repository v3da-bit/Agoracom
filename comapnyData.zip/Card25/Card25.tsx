import moment from 'moment'
import React from 'react'

const Card25 = ({ data }: any) => {
    const style = 'mt-3 font-semibold text-md max-md:text-sm text-gray-600 dark:text-gray-200'
    const { title, created_at, date, time } = data
    return (

        <div className="grid grid-flow-row gap-5 px-4 py-4 rounded-md bg-gray-100 dark:bg-gray-800">
            <h1 className='text-lg max-md:text-md  text-dark mt-3'>
                <b>{title}</b>
            </h1>
            <div>

                <span className="text-neutral-500 dark:text-neutral-400 font-normal">
                    {created_at ? moment(created_at).format('ddd ll') : date}
                </span>
                <span className="text-neutral-500 dark:text-neutral-400 mx-[6px] font-medium">
                    ·
                </span>
                <span className="text-neutral-500 dark:text-neutral-400 font-normal">
                    {created_at ? moment(created_at).format('hh:mm A') : date}
                </span>

            </div>
        </div>

    )
}

export default Card25