import Link from 'next/link'
import React, { FC } from 'react'
import Avatar from '../Avatar/Avatar'
import { Card3SmallProps } from '../Card3Small/Card3Small'
import DefaultAvatar from '../../images/Icons/avatar.png';
import PostCard3 from './PostCard3';



  
const Card23: FC<Card3SmallProps>=({ className = "h-full", post, avatar })=> {
    const { id,title,subTitle,company_name,content, href, featuredImage, avatar_url, username } = post;
    const getUrl = (url: any) => {
        if(url.toString().includes("s3.amazonaws.com")) {
          return url;
        } else {
          return DefaultAvatar;
        }
      }
    return (
    <div
      className={`nc-Card3Small relative flex flex-row items-center ${className}`}
    >
      <Link
        href={href}
        title={title}
        className={`block w-16 flex-shrink-0 relative rounded-lg overflow-hidden z-0 ms-4 group mr-8`}
      >
        <div className={`w-full h-0 aspect-w-1 aspect-h-1`}>
          <Avatar
            sizeClass="h-10 w-10 text-base"
            containerClassName="flex-shrink-0 me-3"
            radius="rounded-full"
            imgUrl={getUrl(avatar_url)}
            userName={username}
          />
          {/* <Image
            alt="featured"
            sizes="100px"
            className="object-cover w-full h-full group-hover:scale-110 transform transition-transform duration-300"
            src={featuredImage || DefaultImage}
            fill
            title={title}
          /> */}
        </div>
      </Link>
      <Link href={href || '/'} className="absolute inset-0" title={title}></Link>
      <div className="relative space-y-2">
        <h2 className="nc-card-title block text-base sm:text-lg font-medium sm:font-semibold text-neutral-900 dark:text-neutral-100">
          <Link href={href || '/'} className="line-clamp-2" title={title}>
            {title}
          </Link>
        </h2>
        <h2 className="nc-card-subtitle block text-sm font-medium text-neutral-900 dark:text-neutral-100">
          <Link href={href || '/'} className="line-clamp-2" title={title}>
            {subTitle}
          </Link>
        </h2>
        <h2 className="nc-card-subtitle block text-sm sm:text-base font-medium text-neutral-900 dark:text-neutral-100">
          <Link href={href || '/'} className="line-clamp-2" title={title}>
            {company_name}
          </Link>
        </h2>
        <h2 className="nc-card-subtitle block text-sm sm:text-base font-medium text-gray-700 dark:text-gray-300">
          <Link href={href || '/'} className="line-clamp-2" title={title}>
            {content}
          </Link>
        </h2>
        <PostCard3 meta={{ ...post }} avatar={avatar_url} hiddenAvatar={true} />
      </div>

      
    </div>
  )
}

export default Card23