import Image from 'next/image'
import React, { useEffect, useState } from 'react'
import DefaultAvatar from '@/images/Icons/avatar.png';
import { useParams, useRouter } from 'next/navigation';
import { getComapnyVideos } from '@/requests/Companies';


const Videos = ({ userData }: any) => {
    const style = 'font-semibold text-xl text-white max-md:text-md'
    const style1 = 'font-semibold text-xl max-md:text-md'
    const style2 = 'font-semibold text-blue-500 text-xl max-md:text-md'
    const params = useParams();
    const router = useRouter();
    const [videoData, setVideoData] = useState([])
    const [pageInfo, setPageInfo] = useState({


        video: {
            showMore: false,
            page: 1
        },
    })
    const [loading, setLoading] = useState({

        video: false,

    })
    const fetchData = async (id: any) => {
        try {
            let payload = { page: pageInfo.video.page };

            const response: any = await getComapnyVideos(id, payload);
            setVideoData(response.data)
            console.log(response);
            let page = JSON.parse(response?.headers.toJSON()?.pagy);

            // console.log(researchInfo);


            setPageInfo({


                video: {
                    ...pageInfo.video,
                    showMore: page.next != null ? true : false
                },
            })



        } catch (e: any) {
            console.log(e);

        }
    }
    const photoPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            video: true
        })
        const newPage = newType ? 1 : pageInfo.video.page + 1;
        let payload = { page: newPage };
        // const type = newType ? newType : discussion;
        let result: any = await getComapnyVideos(userData.id, payload);
        let newData: any = [...videoData, ...result.data];;
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        let pagePayload: any = { ...pageInfo };
        pagePayload["video"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            video: false
        })
        setPageInfo(pagePayload);
        setVideoData(newData);
    }
    useEffect(() => {
        if (params.id) {
            console.log(params.id)
            fetchData(params.id);

        } else {
            router.back();
        }
    }, [])


    const dynamicData = [
        {
            id: 1,
            img: "",
            title: "Nick Cirella",
            created_at: Date.now(),
            content: "President and CED",
            content1: `Mr. Cirella is an extremely dedicated and insighthul entrepreneurial businessman, Mr, Cirella has been involved in the commodity business for over 30 years, 15 of which has been in the computer industry Under his guidance and vision, AIG has grown into a $233,000,000 international conglomerate with offices in Canada, the United States and Europe.`,
            content2: `His hard driving and demanding management style, coupled with his understanding and vision have enabled AIG to map out a strategic and tactical course that has positioned AIG as an industry leader in the supply of computer information technology products and brought it to the leading edge of e commerce in both the business and consumer markets. His strategy of blending the synergies of a leading supplier of computer information technology equipment with the best internet sales channel technology will ensure that. AIG not only prospers in the new Millenium but sets the new benchmark in Internet commerce.`,
            content3: `Mr. Cirella has strong community involvement, supporting numerous charitable organizations through the provision of his time and donations. His business and community achievements have been recently recognized with the investiture by the Governor General of Canada, of Mr. Cirella as a Serving Brother of St. John ('SBSJ)`

        },
        {
            id: 2,
            img: "",
            title: "Dr. Andrew Nellestyn",
            created_at: Date.now(),
            content: "Chainman",
            content1: `Dr. Nellestyn is Chairman &amp; CEO of Andel Inc. Ite has held senior executive positions in leading software engineering and sales companies that develop robust spatial enterprise asset management solutions for telecommunications and utility clients as well as productivity tools for a variety of enterprises world-wide. He has also held a number of executive positions, including CEO, president, CFO, COO, and EVP marketing and sales at companies such as Corel Corporation, Enghouse Systems Limited,
            Bull HN, Atomic Energy of Canada Limited and SSI.`,
            content2: `Dr. Nellestyn is a business leader, academic, volunteer and retred military officer. He retired from the Canadian Armed Forces in 1985, attaining rank of colonel after having served in a variety of command. staff, engineering research and development, export sales and technology development assignments
            Dr. Nellestyn serves on several boards of directors including audit committees`,
            content3: ``
        },
        {
            id: 3,
            img: "",
            title: "Dr.Lloyd Atkinson",
            created_at: Date.now(),
            content: "Board Meniber",
            content1: `Lloyd Atkinson is an independent economic and financial consultant. For nine years, until June 2003, he served as Vice Chairman, Chief Investment Officer, and Chief Strategist at Perigee Investment Counsel Inc. Prior to joining the investment management industry in 1994, Dr. Atlunson was, for 12 years, Executive Vice President and Chief Economist at the Bank of Montreal where he also served as the head
            of the bank's Investment Committee of the Pension Fund Society. Previously, he spent four years working
            for the United States government in Washington, DC. first as Senior Advisor at the Joint Economic
            Committee of the LI.S. Congress, and then as Deputy Assistant Director of the US. Congressional Budget
            Office. He has taught economics and finance at a number of American universities, including the
            University of Michigan and the University of Maryland, and has also served as a consultant to the US
            delegations at the International Monetary Fund and the World Bank. Dr. Ationson holds a Ph.D. in
            economics from The University of Michigan and an Honours Bachelor of Arts degree in economics and
            political science from the University of Windsor. He is a member of the Monetary Policy Council of the
            CD. Howe Institute and a member of the investment Operations Committee, Alberta Revenue. As well he
            is a member of the School of Business and Economics Dean's Advisory Board of Wilfrid Laurier
            University. He serves on the board of the Homewood Corporation.`,
            content2: ``,
            content3: ``
        },
        {
            id: 4,
            img: "",
            title: "Dr.Lloyd Atkinson",
            created_at: Date.now(),
            content: "Board Meniber",
            content1: `Lloyd Atkinson is an independent economic and financial consultant. For nine years, until June 2003, he served as Vice Chairman, Chief Investment Officer, and Chief Strategist at Perigee Investment Counsel Inc. Prior to joining the investment management industry in 1994, Dr. Atlunson was, for 12 years, Executive Vice President and Chief Economist at the Bank of Montreal where he also served as the head
            of the bank's Investment Committee of the Pension Fund Society. Previously, he spent four years working
            for the United States government in Washington, DC. first as Senior Advisor at the Joint Economic
            Committee of the LI.S. Congress, and then as Deputy Assistant Director of the US. Congressional Budget
            Office. He has taught economics and finance at a number of American universities, including the
            University of Michigan and the University of Maryland, and has also served as a consultant to the US
            delegations at the International Monetary Fund and the World Bank. Dr. Ationson holds a Ph.D. in
            economics from The University of Michigan and an Honours Bachelor of Arts degree in economics and
            political science from the University of Windsor. He is a member of the Monetary Policy Council of the
            CD. Howe Institute and a member of the investment Operations Committee, Alberta Revenue. As well he
            is a member of the School of Business and Economics Dean's Advisory Board of Wilfrid Laurier
            University. He serves on the board of the Homewood Corporation.`,
            content2: ``,
            content3: ``
        },
        {
            id: 5,
            img: "",
            title: "Dr.Lloyd Atkinson",
            created_at: Date.now(),
            content: "Board Meniber",
            content1: `Lloyd Atkinson is an independent economic and financial consultant. For nine years, until June 2003, he served as Vice Chairman, Chief Investment Officer, and Chief Strategist at Perigee Investment Counsel Inc. Prior to joining the investment management industry in 1994, Dr. Atlunson was, for 12 years, Executive Vice President and Chief Economist at the Bank of Montreal where he also served as the head
            of the bank's Investment Committee of the Pension Fund Society. Previously, he spent four years working
            for the United States government in Washington, DC. first as Senior Advisor at the Joint Economic
            Committee of the LI.S. Congress, and then as Deputy Assistant Director of the US. Congressional Budget
            Office. He has taught economics and finance at a number of American universities, including the
            University of Michigan and the University of Maryland, and has also served as a consultant to the US
            delegations at the International Monetary Fund and the World Bank. Dr. Ationson holds a Ph.D. in
            economics from The University of Michigan and an Honours Bachelor of Arts degree in economics and
            political science from the University of Windsor. He is a member of the Monetary Policy Council of the
            CD. Howe Institute and a member of the investment Operations Committee, Alberta Revenue. As well he
            is a member of the School of Business and Economics Dean's Advisory Board of Wilfrid Laurier
            University. He serves on the board of the Homewood Corporation.`,
            content2: ``,
            content3: ``
        }
    ]
    return (
        <div className='w-full border-t-2 grid grid-flow-row gap-5 border-black'>
            {videoData.length > 0 ?
                <>
                    <div className="mt-3 grid grid-flow-row gap-2">
                        <div className='w-full h-fit flex justify-center lg:block '>
                            <Image
                                className=' w-full max-h-[456px] h-fit'
                                src={DefaultAvatar}
                                alt="GFG logo served with static path of public directory"
                                height="100"
                                width="100"
                            /> </div>
                        <div className="grid grid-flow-row gap-3">
                            <h1 className={style1}>aa</h1>
                            <div className="flex flex-row gap-3">
                                <div className=' h-8 w-8 rounded-full bg-white'><Image
                                    src={DefaultAvatar}
                                    alt="GFG logo served with static path of public directory"
                                    height="100"
                                    width="400"
                                /> </div>
                                <h1 className={style1}>aa</h1>
                                <h1 className={style2}>aa</h1>
                            </div>
                        </div>
                    </div>


                    <div className="grid grid-cols-3 gap-3">
                        {videoData.map((value: any) => {
                            return (<div className="mt-3 grid grid-flow-row gap-3">
                                <div className='w-full h-fit flex justify-center lg:block '>
                                    <Image
                                        className=' w-full max-h-[456px] h-fit'
                                        src={DefaultAvatar}
                                        alt="GFG logo served with static path of public directory"
                                        height="100"
                                        width="100"
                                    /> </div>
                                <div className="grid grid-flow-row gap-3">
                                    <h1 className={style1}>aa</h1>
                                    <div className="flex flex-row gap-3">
                                        <div className=' h-8 w-8 rounded-full bg-white overflow-hidden'><Image
                                            src={DefaultAvatar}
                                            alt="GFG logo served with static path of public directory"
                                            height="100"
                                            width="400"
                                        /> </div>
                                        <h1 className={style1}>aa</h1>
                                        <h1 className={style2}>aa</h1>
                                    </div>
                                </div>
                            </div>)
                        })}
                    </div>
                </>
                : <></>
            }
        </div>
    )
}

export default Videos