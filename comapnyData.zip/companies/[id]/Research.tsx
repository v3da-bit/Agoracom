import ButtonPrimary from '@/components/Button/ButtonPrimary'
import Image from 'next/image'
import React, { useEffect, useState } from 'react'
import img from '@/images/Icons/avatar.png'
import { useParams, useRouter } from 'next/navigation'
import { getCompanyLinksResearch, getManagersResearch, getResearch } from '@/requests/Companies'
import moment from 'moment'
import Card25 from '@/components/Card25/Card25'


const Research = ({userData}:any) => {
    const style = 'font-semibold text-md max-md:text-sm text-gray-600 dark:text-gray-200'
    const style1 = 'mt-5 font-semibold text-sm text-gray-600 dark:text-gray-200'

    const style2 = 'font-semibold text-sm text-gray-600 dark:text-gray-200'
    const [researchInfo,setResearchInfo]=useState({})
    const [managers,setManagers]=useState([])
    const [companyLinks,setlinks]=useState([])
    
    const params = useParams();
    const router = useRouter();
    const [pageInfo, setPageInfo] = useState({
        
       
        managers:{
            showMore:false,
            page:1
        },
        links:{
            showMore:false,
            page:1
        }
    })
    const [loading, setLoading] = useState({
        
        
        managers:false,
        links:false
        
    })
    const fetchData = async (id: any) => {
        try {
            // let payload = { page: pageInfo.research.page };
            
            const response: any = await getResearch(id);
            const {info,links,managers}=response.data
            console.log(response);
            setResearchInfo(info)
            setManagers(managers.filter((i: any, index: number) => index < 3))
            setlinks(links.filter((i: any, index: number) => index < 3))
            // console.log(researchInfo);
            
        
            setPageInfo({
                
                managers: {
                    ...pageInfo.managers,
                    showMore: links.length>3? true : false
                },
                links: {
                    ...pageInfo.links,
                    showMore: managers.length>3? true : false
                },
            })
            
            
           
        }catch(e:any){
            console.log(e);
            
        }
    }
    const managersPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            managers: true
        })
        const newPage =  pageInfo.managers.page + 1;
        let payload = { page: newPage };
        let result: any = await getManagersResearch(userData.id, payload);
        let newData: any = [...managers, ...result.data];
        console.log(newData);
        
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        console.log(page);
        
        let pagePayload: any = { ...pageInfo };
        pagePayload["managers"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            managers: false
        })
        setPageInfo(pagePayload);
        setManagers(newData);
    }
    const linkPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            links: true
        })
        const newPage =  pageInfo.managers.page + 1;
        let payload = { page: newPage };
        let result: any = await getCompanyLinksResearch(userData.id, payload);
        let newData: any = [...companyLinks, ...result.data];
        console.log(newData);
        
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        console.log(page);
        
        let pagePayload: any = { ...pageInfo };
        pagePayload["links"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            links: false
        })
        setPageInfo(pagePayload);
        setlinks(newData);
    }
    useEffect(() => {
        if (params.id) {
            console.log(params.id)
            fetchData(params.id);

        } else {
            router.back();
        }
    }, [])
  
   
    const dynamicData = [
        {
            id: 1,
            img: "",
            title: "Nick Cirella",
            created_at:Date.now(),
            content: "President and CED",
            content1: `Mr. Cirella is an extremely dedicated and insighthul entrepreneurial businessman, Mr, Cirella has been involved in the commodity business for over 30 years, 15 of which has been in the computer industry Under his guidance and vision, AIG has grown into a $233,000,000 international conglomerate with offices in Canada, the United States and Europe.`,
            content2:`His hard driving and demanding management style, coupled with his understanding and vision have enabled AIG to map out a strategic and tactical course that has positioned AIG as an industry leader in the supply of computer information technology products and brought it to the leading edge of e commerce in both the business and consumer markets. His strategy of blending the synergies of a leading supplier of computer information technology equipment with the best internet sales channel technology will ensure that. AIG not only prospers in the new Millenium but sets the new benchmark in Internet commerce.`,
            content3:`Mr. Cirella has strong community involvement, supporting numerous charitable organizations through the provision of his time and donations. His business and community achievements have been recently recognized with the investiture by the Governor General of Canada, of Mr. Cirella as a Serving Brother of St. John ('SBSJ)`

        },
        {
            id: 2,
            img: "",
            title: "Dr. Andrew Nellestyn",
            created_at:Date.now(),
            content: "Chainman",
            content1:`Dr. Nellestyn is Chairman &amp; CEO of Andel Inc. Ite has held senior executive positions in leading software engineering and sales companies that develop robust spatial enterprise asset management solutions for telecommunications and utility clients as well as productivity tools for a variety of enterprises world-wide. He has also held a number of executive positions, including CEO, president, CFO, COO, and EVP marketing and sales at companies such as Corel Corporation, Enghouse Systems Limited,
            Bull HN, Atomic Energy of Canada Limited and SSI.`,
            content2: `Dr. Nellestyn is a business leader, academic, volunteer and retred military officer. He retired from the Canadian Armed Forces in 1985, attaining rank of colonel after having served in a variety of command. staff, engineering research and development, export sales and technology development assignments
            Dr. Nellestyn serves on several boards of directors including audit committees`,
            content3:``
        },
        {
            id: 3,
            img: "",
            title: "Dr.Lloyd Atkinson",
            created_at:Date.now(),
            content: "Board Meniber",
            content1:`Lloyd Atkinson is an independent economic and financial consultant. For nine years, until June 2003, he served as Vice Chairman, Chief Investment Officer, and Chief Strategist at Perigee Investment Counsel Inc. Prior to joining the investment management industry in 1994, Dr. Atlunson was, for 12 years, Executive Vice President and Chief Economist at the Bank of Montreal where he also served as the head
            of the bank's Investment Committee of the Pension Fund Society. Previously, he spent four years working
            for the United States government in Washington, DC. first as Senior Advisor at the Joint Economic
            Committee of the LI.S. Congress, and then as Deputy Assistant Director of the US. Congressional Budget
            Office. He has taught economics and finance at a number of American universities, including the
            University of Michigan and the University of Maryland, and has also served as a consultant to the US
            delegations at the International Monetary Fund and the World Bank. Dr. Ationson holds a Ph.D. in
            economics from The University of Michigan and an Honours Bachelor of Arts degree in economics and
            political science from the University of Windsor. He is a member of the Monetary Policy Council of the
            CD. Howe Institute and a member of the investment Operations Committee, Alberta Revenue. As well he
            is a member of the School of Business and Economics Dean's Advisory Board of Wilfrid Laurier
            University. He serves on the board of the Homewood Corporation.`,
            content2: ``,
            content3:``
        },
        {
            id: 4,
            img: "",
            title: "Dr.Lloyd Atkinson",
            created_at:Date.now(),
            content: "Board Meniber",
            content1:`Lloyd Atkinson is an independent economic and financial consultant. For nine years, until June 2003, he served as Vice Chairman, Chief Investment Officer, and Chief Strategist at Perigee Investment Counsel Inc. Prior to joining the investment management industry in 1994, Dr. Atlunson was, for 12 years, Executive Vice President and Chief Economist at the Bank of Montreal where he also served as the head
            of the bank's Investment Committee of the Pension Fund Society. Previously, he spent four years working
            for the United States government in Washington, DC. first as Senior Advisor at the Joint Economic
            Committee of the LI.S. Congress, and then as Deputy Assistant Director of the US. Congressional Budget
            Office. He has taught economics and finance at a number of American universities, including the
            University of Michigan and the University of Maryland, and has also served as a consultant to the US
            delegations at the International Monetary Fund and the World Bank. Dr. Ationson holds a Ph.D. in
            economics from The University of Michigan and an Honours Bachelor of Arts degree in economics and
            political science from the University of Windsor. He is a member of the Monetary Policy Council of the
            CD. Howe Institute and a member of the investment Operations Committee, Alberta Revenue. As well he
            is a member of the School of Business and Economics Dean's Advisory Board of Wilfrid Laurier
            University. He serves on the board of the Homewood Corporation.`,
            content2: ``,
            content3:``
        },
        {
            id: 5,
            img: "",
            title: "Dr.Lloyd Atkinson",
            created_at:Date.now(),
            content: "Board Meniber",
            content1:`Lloyd Atkinson is an independent economic and financial consultant. For nine years, until June 2003, he served as Vice Chairman, Chief Investment Officer, and Chief Strategist at Perigee Investment Counsel Inc. Prior to joining the investment management industry in 1994, Dr. Atlunson was, for 12 years, Executive Vice President and Chief Economist at the Bank of Montreal where he also served as the head
            of the bank's Investment Committee of the Pension Fund Society. Previously, he spent four years working
            for the United States government in Washington, DC. first as Senior Advisor at the Joint Economic
            Committee of the LI.S. Congress, and then as Deputy Assistant Director of the US. Congressional Budget
            Office. He has taught economics and finance at a number of American universities, including the
            University of Michigan and the University of Maryland, and has also served as a consultant to the US
            delegations at the International Monetary Fund and the World Bank. Dr. Ationson holds a Ph.D. in
            economics from The University of Michigan and an Honours Bachelor of Arts degree in economics and
            political science from the University of Windsor. He is a member of the Monetary Policy Council of the
            CD. Howe Institute and a member of the investment Operations Committee, Alberta Revenue. As well he
            is a member of the School of Business and Economics Dean's Advisory Board of Wilfrid Laurier
            University. He serves on the board of the Homewood Corporation.`,
            content2: ``,
            content3:``
        }
    ]

    return (
        <div className='w-full border-t-2 border-black'>
            <div className=" container mb-4 mt-4 w-full flex flex-col gap-3 py-3  justify-center">
                <h1 className="mt-3 text-md lg:text-lg text-dark font-bold">{moment(researchInfo.updated_at).format('llll')}</h1>
                <h1 className=" text-md lg:text-lg text-dark font-bold">{researchInfo.tidy_ticker}</h1>
                <h1 className="text-blue-500"><a href='#'>{researchInfo.username}</a></h1>
                <div className="flex flex-col gap-3">
                   <h1 className={style} dangerouslySetInnerHTML={{__html: researchInfo.overview}}></h1>
                   
                </div>
                {managers.length>0?
                <div className="flex flex-col gap-3">
                    <h1 className="mt-3 text-lg lg:text-2xl text-dark font-bold">Management & Directors</h1>
                    {managers.map((value): any => {
                        return (
                            <div className=' w-full px-4 py-4 flex flex-row gap-3 border-gray-300 border rounded-lg bg-gray-200 dark:bg-neutral-900 dark:border-gray-800'>
                                <div className="w-1/4 flex justify-center items-start">
                                    <Image
                                        src={img}
                                        alt="GFG logo served with static path of public directory"
                                        height="100"
                                        width="100"
                                    />
                                </div>
                                <div className="w-3/4 flex flex-col gap-3">
                                    <h1 className="text-xl font-bold max-md:text-md  text-dark">{value.title}</h1>
                                    <div>
                                    <h1 className={style}>{value.content}</h1>
                                    <h1 className={style1}>{value.content1}</h1>
                                    <h1 className={style2}>{value.content2}</h1>
                                    <h1 className={style2}>{value.content3}</h1>
                                    </div>
                                </div>


                            </div>

                        )
                    })}
                    {pageInfo.managers.showMore?<div className="flex mt-5 justify-center items-center">
                        <ButtonPrimary loading={loading.managers} onClick={()=>managersPosts()} className=''><span className=''>Show More</span></ButtonPrimary>
                    </div>:<></>}

                </div>
                :<></>}
                {companyLinks.length>0?
                <div className="flex flex-col gap-3">
                    <h1 className="mt-3 text-lg lg:text-3xl text-dark font-bold">Company Links</h1>
                    {companyLinks?.map((post: any, index: number) => {
                        post.href = '/';
                        // if(index <= 4) {
                        return (
                            <Card25
                                data={post}

                            />
                        )
                        // }
                    })}
                    {pageInfo.links.showMore?<div className="flex mt-5 justify-center items-center">
                        <ButtonPrimary loading={loading.links} onClick={()=>linkPosts()} className=''><span className=''>Show More</span></ButtonPrimary>
                    </div>:<></>}
                </div>
                :<></>}

            </div>
        </div>
    )
}

export default Research