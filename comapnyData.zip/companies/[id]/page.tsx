'use client';
import Heading from '@/components/Heading/Heading'
import Nav from '@/components/Nav/Nav'
import NavItem from '@/components/NavItem/NavItem'
import React, { useEffect, useState } from 'react'
import View from './View';
import { DEMO_POSTS } from '@/data/posts'
import HomeFeatured from './HomeFeatured';
import ButtonPrimary from '@/components/Button/ButtonPrimary';
import Image from 'next/image';
import DefaulAvatar from '@/images/favicon.png'
import Input from '@/components/Input/Input';
import ButtonCircle from '@/components/Button/ButtonCircle';
import { MagnifyingGlassIcon, PlusIcon } from '@heroicons/react/24/solid';
import FooterHomeBsm from './FooterHomeBsm';
import Discussion from './Discussion';
import PressRelease from './PressRelease';
import Qna from './Qna';
import ButtonSecondary from '@/components/Button/ButtonSecondary';
import Research from './Research';
import { useParams, useRouter } from 'next/navigation';
import { getCompanies, getMoreCompanies } from '@/requests/Home';
import { getBulletins, getDiscussion, getMembers } from '@/requests/Companies';
import Link from 'next/link';
import Photos from './Photos';
import Videos from './Videos';



export let discuss=[]
const page=()=> {
    const [discussion, setDiscussion] = useState([]);
    const params = useParams();
    const router = useRouter();
    const [bulletins, setBulletins] = useState([]);
    const [info, setInfo]: any = useState({});
    const [topMembers, setTopMembers] = useState([]);
    const [FeaturedPosts, setFeaturedPosts] = useState([]);
    const [userData, setUserData]: any = useState({});
    const [appliedFilters, setAppliedFilters] = useState([]);
    const [loader, setLoader] = useState({
        discussion: false,
        recentDiscussion: false
    })
    const getList = (list: any) => {
        if(list.length > 0) {
            let stringData = list.toString();
            let dataList: any = stringData.replaceAll(',', '","');
            return `["${dataList}"]`;
        } else {
            return null;
        }
    }
    // const [postData, setPosts] = useState([]);
    const [loading, setLoading] = useState({
        posts: false,
        members: false,
        followedHub: false,
        leadingHub: false
    })
    const [pageInfo, setPageInfo] = useState({
        bulletin: {
            showMore: false,
            page: 1
        },
        discussions: {
            showMore: false,
            page: 1
        },
        members: {
            showMore: false,
            page: 1
        },
        
    })
    const menuDropdown: any = {
        'posts': "Newest",
        'top_rated_posts': "Top Rated",
        'oldest_posts': "Oldest"
    };
    console.log("disscussions len:",discussion.length);
    const [keyword, setKeyword] = useState("");
    const [filters, setFilters]: any = useState([]);

      
    useEffect(() => {
        if (params.id) {
            console.log(params.id)
            fetchData(params.id);

        } else {
            router.back();
        }
    }, [])

    const filterData = async (filter: any = [], fromFilter = false) => {
        
        router.push('/search')
        console.log("filter clicked");
        
        setLoader({
            ...loader,
            discussion: true
        })
        const newPage = 1;
        let payload: any = {page: newPage};
        if(keyword) {
            payload["q"] = keyword;
        }
        let filterList = fromFilter ? getList(filter) : getList(appliedFilters);
        if(filterList) {
            payload["category"] = filterList;
        }
        let result: any = await getDiscussion(userData.id,payload);
        let newData: any = [...result.data];
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        let pagePayload: any = {...pageInfo};
        pagePayload["discussions"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoader({
            ...loader,
            discussion: false
        })
        setPageInfo(pagePayload);
        setDiscussion(newData);
        discuss=discussion
    }
    const searchKeyword = (e: any) => {
        e.preventDefault();
        e.stopPropagation();
        filterData();
    }
    const fetchData = async (id: any) => {
        try {
            const response: any = await getCompanies(id);
            console.log(response);
            if (response.status === 200) {
                const { bulletins, discussions, info, featured_posts, top_members } = response.data;
                
                
                
                setUserData(info)
                setBulletins(bulletins.filter((i: any, index: number) => index < 4))
                setDiscussion(discussions.filter((i: any, index: number) => index < 5))
                setTopMembers(top_members.filter((i: any, index: number) => index < 6))
                setInfo(info)
                setFeaturedPosts(featured_posts)
                setPageInfo({
                    bulletin: {
                        ...pageInfo.bulletin,
                        showMore: bulletins.length > 4 ? true : false
                    },
                    members: {
                        ...pageInfo.members,
                        showMore: topMembers.length > 6 ? true : false
                    },
                    discussions: {
                        ...pageInfo.discussions,
                        showMore: discussions.length > 5 ? true : false
                    },
                    
                })
                
               
            }
        } catch (e: any) {
            console.log(e);
        }
    }

    const bulletinsPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            posts: true
        })
        const newPage = newType ? 1 : pageInfo.bulletin.page + 1;
        let payload = { page: newPage };
        // const type = newType ? newType : discussion;
        let result: any = await getBulletins( userData.id, payload);
        let newData: any=[...bulletins, ...result.data];;
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        let pagePayload: any = { ...pageInfo };
        pagePayload["bulletin"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            posts: false
        })
        setPageInfo(pagePayload);
        setBulletins(newData);
    }
    const discussionPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            followedHub: true
        })
        const newPage = newType ? 1 : pageInfo.discussions.page + 1;
        let payload = { page: newPage };
        let result: any = await getDiscussion(userData.id, payload);
        let newData: any = [...discussion, ...result.data];
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        console.log(page);
        
        let pagePayload: any = { ...pageInfo };
        pagePayload["discussions"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            followedHub: false
        })
        setPageInfo(pagePayload);
        setDiscussion(newData);
    }

    const loadMembers = async () => {
        setLoading({
            ...loading,
            members: true
        })
        const newPage = pageInfo.members.page + 1;
        let payload = { page: newPage };
        let result: any = await getMembers(userData.id, payload);
        let newData: any = [...topMembers, ...result.data];
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        let pagePayload: any = { ...pageInfo };
        pagePayload["members"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            members: false
        })
        setPageInfo(pagePayload);
        setTopMembers(newData);
    }
    useEffect(() => {
        if (params.id) {
            console.log(params.id)
            fetchData(params.id);

        } else {
            router.back();
        }
    }, [])
    
    const style = 'mt-3 font-semibold text-md max-md:text-sm text-gray-600 dark:text-gray-200 line-clamp-5'
    const style1 = 'mt-3 font-semibold text-sm text-gray-600 dark:text-gray-200'

    const style2 = 'mt-3 font-semibold text-right text-sm text-dark'
    
    const tabs: any = [
        { id: 1, title: "Home", icon: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" },
        { id: 2, title: "Discussion", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },
        { id: 3, title: "Research", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },
        { id: 4, title: "Press Release", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },
        { id: 5, title: "Photo", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },
        { id: 6, title: "Videos", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },
        { id: 7, title: "Links Library", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },
        { id: 8, title: "Q&A", icon: "M3.75 6.75h16.5M3.75 12H12m-8.25 5.25h16.5" },


    ]
    
    const [tabActive, setTabActive] = useState<number>(tabs[0].id);
    const handleClickTab = (item: number) => {
        if (item === tabActive) {
            return;
        }
        setTabActive(item);
    };

    const posts = DEMO_POSTS.filter(
        (_, i) => i > 2 && i < 7
    );
    return (
        <div>
            <div className='container flex flex-row  max-xl:justify-center max-xl:flex-col max-xl:items-center gap-5 xl:gap-8 py-8 px-4'>
                <div className='flex flex-col w-3/4 gap-3 max-xl:w-full'>
                    <Heading desc={""} isCenter className="text-defaultBlue-100 mb-9">
                        {info.name}'s Profile
                    </Heading>
                    <h1 className={style}><p className="MsoNormal">{bulletins[0]?.content}</p></h1>
                    <div className="mt-6">
                        <div className="flex-none lg:flex gap-6">
                            <div className="grow">
                                <div className="flex-none lg:flex justify-between mb-7">
                                    <Nav
                                        className="sm:space-x-2 rtl:space-x-reverse"
                                        containerClassName="relative flex w-full overflow-x-auto text-sm md:text-base"
                                    >
                                        {tabs.map((item: any, index: number) => (
                                            <NavItem
                                                className='px-4 py-3 text-sm'
                                                key={item.id}
                                                isActive={tabActive === item.id}
                                                onClick={() => handleClickTab(item.id)}
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6 mr-1">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d={item.icon} />
                                                </svg>
                                                {item.title}
                                            </NavItem>
                                        ))}
                                    </Nav>

                                </div>
                                <div className=" mb-7 px-0 lg:px-4">
                                    {tabActive == 1 ? <HomeFeatured post={FeaturedPosts} pageInfo={pageInfo?.discussions?.showMore} loader={loading.followedHub} onclick={discussionPosts} keyword={keyword} setKeyword={setKeyword} searchKeyword={searchKeyword} discussions={discussion}/> : tabActive == 2 ? <Discussion/>:tabActive==3?<Research userData={userData}/>: tabActive == 4 ? <PressRelease userData={userData}/> :tabActive==5?<Photos userData={userData}/>:tabActive==6?<Videos userData={userData}/>:tabActive==8?<Qna/>: <View />}
                                </div>



                            </div>

                        </div>

                    </div>
                </div>
                <div className='flex flex-col w-1/4 max-xl:w-1/2 max-lg:w-full   h-fit px-7 py-7 shadow-md border-gray-300 border  rounded-xl bg-white dark:bg-neutral-900 dark:border-gray-800'>
                    <div className=" flex flex-row justify-center items-center">
                        <div className="w-40  h-40 overflow-hidden  rounded-full  flex ">
                            <Image
                                src={info.small_logo_url}
                                alt="GFG logo served with static path of public directory"
                                height="250"
                                width="250"
                            />
                        </div>
                        
                    </div>
                    <div className=' text-center flex flex-col gap-3 mt-3'>
                        <h1 className="text-2xl max-md:text-lg  text-dark"><b>{info.name}</b></h1>
                        <h1 className="text-blue-500 "><b>Stock Quotes</b></h1>
                        <div className="flex-shrink-0 w-full  lg:mb-0 grow lg:grow-0 lg:!w-[260px] sm:!w-full">
                            <form className="relative">
                                <Input
                                    required
                                    aria-required
                                    placeholder="Search Keyword"
                                    type="text"
                                    value={""}
                                    // onChange={(e) => setKeyword(e.target.value)}
                                    className="text-neutral-800 px-6 dark:text-neutral-200"
                                />
                                <ButtonCircle
                                    type="submit"
                                    // disabled={!keyword.length}
                                    // onClick={searchKeyword}
                                    className={`absolute transform top-1/2 -translate-y-1/2 end-1 !bg-defaultGreen-100 hover:!bg-primary-500 dark:bg-neutral-300 dark:text-black`}
                                >
                                    <MagnifyingGlassIcon className="w-5 h-5" />
                                </ButtonCircle>
                            </form>
                        </div>
                        <div className='grid grid-flow-row gap-3 '>
                            <div className="grid grid-flow-col text-left">
                                <h1 className={style1}>Symbol</h1>
                                <h1 className={style2}>{info.tidy_ticker}</h1>
                            </div>
                            <div className="grid grid-flow-col text-left">
                                <h1 className={style1}>Exchange</h1>
                                <h1 className={style2}>{info.stock_exchange}</h1>
                            </div>
                            <div className="grid grid-flow-col text-left">
                                <h1 className={style1}>Shares</h1>
                                <h1 className={style2}>{info.outstanding_shares}</h1>
                            </div>

                            <div className="grid grid-flow-col text-left">
                                <h1 className={style1}>Industry</h1>
                                <h1 className={style2}><a href="/">{info.industry}</a></h1>
                            </div>
                            <div className="grid grid-flow-col text-left">
                                <h1 className={style1}>Website</h1>
                                <h1 className={style2}><a href={info.external_website}>Click Here</a></h1>
                            </div>

                            <div className="flex mt-3 justify-center items-center">
                                <ButtonSecondary className='w-full '><span className=''>Create a Post</span></ButtonSecondary>
                            </div>
                            <div className="flex justify-center items-center">
                                <ButtonPrimary className='w-full text-base'><span className=''> Follow Hub</span></ButtonPrimary>
                            </div>
                            <div className="flex justify-center items-center">
                                <ButtonPrimary className='w-full bg-white hover:bg-slate-200'><span className=' text-black'>DISCLAIMER</span></ButtonPrimary>
                            </div>

                        </div>


                    </div>

                </div>
            </div>
            
                {tabActive == 1 ? <FooterHomeBsm loader={loading.posts} loader2={loading.members} pageInfo={pageInfo?.bulletin?.showMore} pageInfo2={pageInfo?.members?.showMore} onclick={bulletinsPosts} onclick2={loadMembers} name={info.name} data={bulletins} topMembers={topMembers} />:<></>}
            


        </div>
    )
}

export default page

