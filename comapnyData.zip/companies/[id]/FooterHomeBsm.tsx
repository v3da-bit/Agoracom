import ButtonCircle from '@/components/Button/ButtonCircle';
import ButtonPrimary from '@/components/Button/ButtonPrimary';
import Card24 from '@/components/Card24/Card24';
import Input from '@/components/Input/Input';
import { MagnifyingGlassIcon, PlusIcon } from '@heroicons/react/24/solid';
import Image from 'next/image';
import React from 'react'
import ReactStars from "react-rating-stars-component";
import DefaultAvatar2 from '@/images/Icons/avatar.png'


function FooterHomeBsm({ name, data, topMembers, loader, loader2, onclick, onclick2, pageInfo, pageInfo2 }: any) {
    const style1 = 'mt-3 font-semibold text-sm text-gray-600 dark:text-gray-200'
    const url = "https://s3.amazonaws.com/s3-staging.agoracom.com/public/users/"
    const style2 = 'mt-3 font-semibold text-right text-sm text-dark'
    console.log(pageInfo)

    return (
        <div>
            <div className='w-full bg-gray-300 dark:bg-gray-800'>
                {topMembers.length>0?<div className=" container mb-8 mt-8 w-full flex flex-col gap-3 py-3  justify-center">
                    <h1 className="mt-3 text-lg lg:text-2xl text-dark font-bold">Top Members</h1>
                    <div className="flex-shrink-0  lg:mb-0 grow lg:grow-0 lg:!w-[260px] sm:!w-full">
                        <form className="relative">
                            <Input
                                required
                                aria-required
                                placeholder="Search Keyword"
                                type="text"
                                value={""}
                                // onChange={(e) => setKeyword(e.target.value)}
                                className="text-neutral-800 px-6 dark:text-neutral-200"
                            />
                            <ButtonCircle
                                type="submit"
                                // disabled={!keyword.length}
                                // onClick={searchKeyword}
                                className={`absolute transform top-1/2 -translate-y-1/2 end-1 !bg-defaultGreen-100 hover:!bg-primary-500 dark:bg-neutral-300 dark:text-black`}
                            >
                                <MagnifyingGlassIcon className="w-5 h-5" />
                            </ButtonCircle>
                        </form>
                    </div>
                    <div className="mt-3 grid grid-cols-1 lg:grid-cols-2 gap-5">
                        {topMembers?.map((value: any) => {
                            console.log(value.avatar.includes("https://s3.amazonaws.com/s3-staging.agoracom.com/public/users/") ? value.avatar : url + value.avatar);
                            return (
                                <div className='   w-full  h-fit px-8 py-8 border-gray-700 border  rounded-xl bg-white dark:bg-neutral-900 dark:border-gray-800'>
                                    <div className=" flex flex-row gap-3">
                                        <div className="w-1/2 h-full  flex justify-center">
                                            <Image
                                                src={value.avatar.includes("https://s3.amazonaws.com/s3-staging.agoracom.com/public/users/") ? value.avatar : url + value.avatar}
                                                alt="GFG logo served with static path of public directory"
                                                height="100"
                                                width="100"
                                            />
                                        </div>
                                        <div className="w-1/2 flex flex-col items-start justify-center">
                                            <h1 className=" text-2xl max-md:text-lg  text-dark"><b>{value.username}</b></h1>
                                            <h1 className=" text-lg max-md:text-sm  text-dark bg-yellow-300 dark:bg-inherit"><b> {value.authority_group_name}</b></h1>


                                        </div>
                                    </div>
                                    <div className='mt-3 grid grid-cols-3 gap-3 '>
                                        <div className="text-center">
                                            <h1 className={style1}>Last posted</h1>
                                            <h1 className={style1}>{value.last_posted}</h1>

                                        </div>
                                        <div className=" text-center">
                                            <h1 className={style1}>Rating</h1>
                                            <h1 className={style1}><ReactStars
                                                count={5}
                                                classNames="flex justify-end"
                                                // onChange={ratingChanged}
                                                value={value.rating}
                                                edit={false}
                                                size={24}
                                                activeColor="#ffd700"
                                            /></h1>

                                        </div>
                                        <div className=" text-center">
                                            <h1 className={style1}>Messages</h1>
                                            <h1 className={style1}>{value.total_messages}</h1>

                                        </div>

                                    </div>
                                    <div className=" mt-5 grid grid-cols-2 max-sm:grid-cols-1 gap-5">
                                        <div className="flex  justify-center items-center">
                                            <ButtonPrimary className='w-full' sizeClass="py-4 px-3 sm:py-3.5 sm:px-6">Private Message</ButtonPrimary>
                                        </div>
                                        <div className="flex justify-center items-center">
                                            <ButtonPrimary className='w-full text-base'><PlusIcon className="w-5 mr-1 h-5 font-semibold " /><span className=''> Follow</span></ButtonPrimary>
                                        </div>
                                    </div>

                                </div>
                            )
                        })}
                        {pageInfo2 ? <div className="flex justify-center items-center mt-5">
                            <ButtonPrimary loading={loader2} onClick={() => onclick2()} className=''>Show more</ButtonPrimary>
                        </div> : <></>}

                    </div>
                </div>:<></>}
                
            </div>
            {data.length>0?<div className=" container mb-8 mt-8 w-full flex flex-col gap-4 py-3  justify-center">
                <h1 className="mt-3 text-lg lg:text-2xl text-dark font-bold">{name}'s Bulletin</h1>
                <div className="grid grid-cols-3 gap-4 max-lg:grid-cols-2 max-sm:grid-cols-1">
                    {data?.map((post: any, index: number) => {
                        post.href = '/';
                        // if(index <= 4) {
                        return (
                            <Card24
                                className="p-4 xl:px-5 xl:py-6 hover:bg-neutral-200 dark:hover:bg-neutral-700"
                                key={post.id}
                                post={post}
                                avatar={post.avatar_url}
                            />
                        )
                        // }
                    })}
                </div>
                {pageInfo ? <div className="flex justify-center items-center mt-5">
                    <ButtonPrimary loading={loader} onClick={() => onclick()} className=''>Show more</ButtonPrimary>
                </div> : <></>}

            </div>:<></>}
            
        </div>
    )
}

export default FooterHomeBsm