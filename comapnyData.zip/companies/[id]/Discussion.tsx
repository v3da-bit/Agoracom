import ButtonCircle from '@/components/Button/ButtonCircle';
import ButtonPrimary from '@/components/Button/ButtonPrimary';
import Card23 from '@/components/Card23/Card23';
import Input from '@/components/Input/Input';
import Select from '@/components/Select/Select';
import { getDiscussion } from '@/requests/Companies';
import { getCompanies } from '@/requests/Home';
import { MagnifyingGlassIcon, PlusIcon } from '@heroicons/react/24/solid';
import { useParams, useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react'

function Discussion() {
    const [discussion, setDiscussion] = useState([]);
    const params = useParams();
    const router = useRouter();
    const [info, setInfo]: any = useState({});
    const [discussion1,setDiscussion1]=useState([])
    const [userData, setUserData]: any = useState({});
    
    const [pageInfo, setPageInfo] = useState({
        
        discussions: {
            showMore: false,
            page: 1
        },
    })
    const [loading, setLoading] = useState({
        
        followedHub: false,
        
    })
    const fetchData = async (id: any) => {
        try {
            const response: any = await getCompanies(id);
            console.log(response);
            if (response.status === 200) {
                const {  bulletins, discussions, info, featured_posts, top_members} = response.data;
                
                
                setUserData(info)
                setDiscussion(discussions.filter((i: any, index: number) => index < 5))
                
                setInfo(info)
                
                setPageInfo({
                    
                    discussions: {
                        ...pageInfo.discussions,
                        showMore: discussions.length > 5 ? true : false
                    },
                    
                })
                
               
            }
        } catch (e: any) {
            console.log(e);
        }
    }
    const discussionPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            followedHub: true
        })
        const newPage =  pageInfo.discussions.page + 1;
        let payload = { page: newPage };
        let result: any = await getDiscussion(userData.id, payload);
        let newData: any = [...discussion, ...result.data];
        console.log(newData);
        
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        console.log(page);
        
        let pagePayload: any = { ...pageInfo };
        pagePayload["discussions"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            followedHub: false
        })
        setPageInfo(pagePayload);
        setDiscussion(newData);
    }
    useEffect(() => {
        if (params.id) {
            console.log(params.id)
            fetchData(params.id);

        } else {
            router.back();
        }
    }, [])
    const menuDropdown: any = {
        0: "Discussions",
        1: "My Feed",
        2: "Featured",
        3: "Followed Companies",
        4: "Followed Posts",
        5: "Followed Members",
        6: "Trending",
        7: "Top Rated",
        8: "Newest",
    };
    const data = [
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            // content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            // content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            // content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            // content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },
        {
            title: "hello world ",
            subTitle: "hello world2",
            // content: "hello world3",
            href: "",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2001",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        }
    ]
    return (
        <div className="mt-3 border-t-2 w-full border-black grid grid-flow-row gap-5">
            <h1 className='text-md mt-5 md:text-xl text-dark xl:text-3xl '>
                <b>Discussion</b>
            </h1>
            <div className="grid grid-cols-2 max-md:grid-cols-1 gap-3">
                <div className="w-full">
                    <div className="flex-shrink-0  lg:mb-0 grow lg:grow-0 lg:!w-[260px] sm:!w-full">
                        <form className="relative">
                            <Input
                                required
                                aria-required
                                placeholder="Search Keyword"
                                type="text"
                                value={""}
                                // onChange={(e) => setKeyword(e.target.value)}
                                className="text-neutral-800 px-6 dark:text-neutral-200"
                            />
                            <ButtonCircle
                                type="submit"
                                // disabled={!keyword.length}
                                // onClick={searchKeyword}
                                className={`absolute transform top-1/2 -translate-y-1/2 end-1 !bg-defaultGreen-100 hover:!bg-primary-500 dark:bg-neutral-300 dark:text-black`}
                            >
                                <MagnifyingGlassIcon className="w-5 h-5" />
                            </ButtonCircle>
                        </form>
                    </div>
                </div>
                <div className="w-full grid grid-cols-2 max-sm:grid-cols-1 gap-2">
                    <div className="flex justify-center">
                        <Select menuDropdown={menuDropdown} selectedValue={discussion1} setMenu={setDiscussion1} />
                    </div>

                    <div className="flex justify-center ">
                        <ButtonPrimary className=' bg-white text-base hover:bg-slate-300 border border-slate-300' sizeClass=' py-2.5 px-3'><span className=' text-blue-600'> Create a Post</span><PlusIcon className=" w-5 mr-1 h-5 font-semibold  text-blue-600" /></ButtonPrimary>
                    </div>
                </div>
            </div>
            <div className="flex flex-col divide-y divide-neutral-200 dark:divide-neutral-700">
                {discussion?.map((post: any, index: number) => {
                    post.href = '/';
                    // if(index <= 4) {
                    return (
                        <Card23
                            className="p-4 xl:px-5 xl:py-6 hover:bg-neutral-200 dark:hover:bg-neutral-700"
                            key={post.id}
                            post={post}
                            avatar={post.avatar_url}
                        />
                    )
                    // }
                })}



            </div>
            {pageInfo.discussions.showMore?
                <div className="flex mt-10 justify-center items-center">
                    <ButtonPrimary loading={loading.followedHub} onClick={()=>discussionPosts()}>Show more</ButtonPrimary>
                </div>:<></>}
        </div>
    )
}

export default Discussion