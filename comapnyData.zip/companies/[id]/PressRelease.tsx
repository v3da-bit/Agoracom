
import page from '@/app/services/page';
import ButtonPrimary from '@/components/Button/ButtonPrimary';
import Card24 from '@/components/Card24/Card24';
import Card25 from '@/components/Card25/Card25';
import { getPressRelease } from '@/requests/Companies';
import { useParams, useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react';

const PressRelease = ({userData}:any) => {
    const [pressRelease,setPressRelease]=useState([])
    const params = useParams();
    const router = useRouter();
   
    const [pageInfo, setPageInfo] = useState({
        
        pressReleases: {
            showMore: false,
            page: 1
        },
    })
    const [loading, setLoading] = useState({
        
        press: false,
        
    })
    const fetchData = async (id: any) => {
        try {
            let payload = { page: pageInfo.pressReleases.page };
            const response: any = await getPressRelease(id,payload);
            console.log("press:",response);
            if (response.status === 200) {
               
                setPressRelease(response.data)
                let page = JSON.parse(response?.headers.toJSON()?.pagy);
        
                setPageInfo({
                    pressReleases: {
                        ...pageInfo.pressReleases,
                        showMore: page.next != null? true : false
                    },
                })
            }
            
        }catch(e:any){
            console.log(e);
        }
    }
    const pressPosts = async (newType: string = '') => {
        setLoading({
            ...loading,
            press: true
        })
        const newPage = newType ? 1 : pageInfo.pressReleases.page + 1;
        let payload = { page: newPage };
        // const type = newType ? newType : discussion;
        let result: any = await getPressRelease( userData.id, payload);
        let newData: any=[...pressRelease, ...result.data];;
        let page = JSON.parse(result?.headers.toJSON()?.pagy);
        let pagePayload: any = { ...pageInfo };
        pagePayload["pressReleases"] = {
            showMore: page.next != null,
            page: newPage
        }
        setLoading({
            ...loading,
            press: false
        })
        setPageInfo(pagePayload);
        setPressRelease(newData);
    }
    useEffect(() => {
        if (params.id) {
            console.log(params.id)
            fetchData(params.id);

        } else {
            router.back();
        }
    }, [])
    
    const data = [
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            company: "BSM Technologies",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            company: "BSM Technologies",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },
        {
            title: "Empower Clinics Inc. - Planned Corporate Updates",
            subTitle: "Empower Clinics Inc",
            content: "We have been receving a number of messgaes in the past few days, so rather than attempting to respond to each message, I can offer the following.",
            href: "",
            company: "BSM Technologies",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2021",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        },

        {
            title: "hello world ",
            subTitle: "hello world2",
            content: "hello world3",
            company: "BSM Technologies",
            href: "",
            date: Date.now(),
            author: "vedant khamar",
            created_at: "1 january 2001",
            featuredImage: "",
            avatar_url: "",
            username: "vedant"
        }
    ]
    return (
        <div className='w-full border-t-2 border-black'>
            <div className=" container mb-4 mt-4 w-full flex flex-col gap-3 py-3  justify-center">
                <h1 className="mt-3 text-lg lg:text-2xl text-dark font-bold">Press Release</h1>
                <div className="flex relative flex-col gap-4">
                    {pressRelease?.map((post: any, index: number) => {
                        post.href = '/';
                        // if(index <= 4) {
                        return (
                            <Card25
                                data={post}

                            />
                        )
                        // }
                    })}

                    {pageInfo.pressReleases.showMore?<div className="flex mt-5 justify-center items-center">
                        <ButtonPrimary loading={loading.press} onClick={()=>pressPosts()} className=''><span className=''>Show More</span></ButtonPrimary>
                    </div>:<></>}
                </div>
            </div>
        </div>
    )
}

export default PressRelease