import Image from 'next/image'
import React, { useState } from 'react'
import DefaultAvatar from '@/images/favicon.png'
import ButtonCircle from '@/components/Button/ButtonCircle'
import { MagnifyingGlassIcon } from '@heroicons/react/24/solid'
import Input from '@/components/Input/Input'
import Select from '@/components/Select/Select'
import ButtonSecondary from '@/components/Button/ButtonSecondary'

const Qna = () => {
    const style1 = 'mt-1 font-semibold text-sm text-gray-600 dark:text-gray-200'
    const [discussion, setDiscussion] = useState(0);
    const menuDropdown: any = {
        0: "Discussions",
        1: "My Feed",
        2: "Featured",
        3: "Followed Companies",
        4: "Followed Posts",
        5: "Followed Members",
        6: "Trending",
        7: "Top Rated",
        8: "Newest",
    };
    return (
        <div className='w-full border-t-2 border-black'>
            <div className=" container mb-4 mt-4 w-full flex flex-col gap-3 py-3  justify-center">
                <h1 className="mt-3 text-lg lg:text-2xl text-dark font-bold">BSM Technologies's Q&A</h1>
                <div className="grid grid-cols-2 gap-3 max-md:grid-cols-1">
                    <div className="flex-shrink-0  lg:mb-0 grow lg:grow-0 lg:!w-[260px] sm:!w-full">
                        <form className="relative">
                            <Input
                                required
                                aria-required
                                placeholder="Search Keyword"
                                type="text"
                                value={""}
                                // onChange={(e) => setKeyword(e.target.value)}
                                className="text-neutral-800 px-6 dark:text-neutral-200"
                            />
                            <ButtonCircle
                                type="submit"
                                // disabled={!keyword.length}
                                // onClick={searchKeyword}
                                className={`absolute transform top-1/2 -translate-y-1/2 end-1 !bg-defaultGreen-100 hover:!bg-primary-500 dark:bg-neutral-300 dark:text-black`}
                            >
                                <MagnifyingGlassIcon className="w-5 h-5" />
                            </ButtonCircle>
                        </form>
                    </div>
                    <div className="flex justify-end max-md:justify-center mt-3 -mb-3 lg:mt-0 lg:mb-0">
                        <ButtonSecondary>Ask a Question ?</ButtonSecondary>
                    </div>
                </div>
                <div className="mt-3 border-t-2 py-3 border-gray-300">
                    <div className="grid grid-flow-row gap-5 px-4 py-4 rounded-md bg-gray-100 dark:bg-gray-800">
                        <h1 className='text-xl max-md:text-md  text-dark mt-3'>
                            <b>NEWS - BSM Technologies Closes Acquisition of Netistix Technologies</b>
                        </h1>
                        <div>
                            <h1 className={style1}>
                                BSM Wireless automatic vehicle security and location solutions and Netistic Technologies
                            </h1>
                            <h1 className={style1}>
                                Fleet Pulse vehicle diagnostic and fuel consumption solutions create the world&rsquo;s most
                            </h1>
                            <h1 className={style1}>
                                comprehensive Fleet Management Product Sulle
                            </h1>
                        </div>
                        <div className='mt-4 flex flex-row gap-2 items-center'>

                            <div className=' h-8 w-8 rounded-full bg-white overflow-hidden'><Image
                                src={DefaultAvatar}
                                alt="GFG logo served with static path of public directory"
                                height="100"
                                width="400"
                            /> </div>
                            <div className="flex flex-row  max-lg:flex-col gap-2">
                                <h1 className="text-blue-500"><b>AGORACOM</b></h1>
                                <h1 className="text-dark "><b>BSM Technologies <span className='text-blue-400'>almost 16 years ago</span></b></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Qna