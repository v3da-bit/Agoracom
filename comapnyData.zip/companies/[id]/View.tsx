import React from 'react'

function View() {
  return (
    <div>View</div>
  )
}

export default View