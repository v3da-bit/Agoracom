import React from 'react'
import DefaultAvatar from '../../images/default-image.jpg';
import Image from 'next/image';


const Card26 = ({post}:any) => {
  const style1 = 'mt-3 font-semibold text-sm text-gray-600 dark:text-gray-200'
  const getUrl = (url: any) => {
    if (url.toString().includes("s3.amazonaws.com")) {
        return url;
    } else {
        return DefaultAvatar;
    }
}
  return (
    <div className='grid border shadow-md rounded-md px-3 pb-4 grid-flow-row gap-4'>
        <div className='w-full h-auto px-3 flex justify-center lg:block '>
                <Image
                    className=' w-full h-fit'
                    src={getUrl(post.image_url)}
                    alt="GFG logo served with static path of public directory"
                    height="100"
                    width="100"
                /> </div>
                <div className="w-full">
                  <h1 className={style1}>{post.title}</h1>
                </div>
    </div>
  )
}

export default Card26